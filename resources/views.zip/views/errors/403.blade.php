@extends('layouts.error')
@section('msg')
    Whoops, 403 Forbidden.
@endsection