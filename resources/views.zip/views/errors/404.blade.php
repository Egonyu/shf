@extends('layouts.error')
@section('msg')
    Whoops, 404 Not Found.
@endsection