@extends('layouts.error')
@section('msg')
    Whoops, 500 Internal Server Error.
@endsection
