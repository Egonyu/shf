@extends('layouts.error', ['show_links'=>false])
@section('msg')
    Be right back.
@endsection
