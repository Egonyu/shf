@extends('pages.master')

@section('content')
<div class="section" data-background=" {{ asset('frontend/images/slider/smoke.jpg') }} ">
    <div class="content-wrap">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-6">
                    <h2 class="section-heading light">
                        join <span>Us</span>
                    </h2>

                    <h2 class="color-white"><span class="color-primary">No Jobs Available at the Moment</h2>
                    </div>

                <!-- <div class="col-sm-6 col-md-6">
                    <div class="img-button">
                        <img src=" {{ asset('frontend/images/slider/sea.jpg') }} " alt="">
                        <div class="btn-overlay">
                            
                        <a href="#" class="btn btn-primary">DONATE NOW</a>
                        </div>
                    </div>
                </div> -->

            </div>
        </div>
    </div>
</div>
    <a href="pdf/volunteerForm.pdf" /> Click here</a>
@endsection