<div class="card">
    <div class="card-body text-center">
        <h4 class="card-title">No data.</h4>
    </div>
</div>